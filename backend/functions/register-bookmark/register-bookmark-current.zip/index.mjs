import {
  DynamoDBClient,
  PutItemCommand
} from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({});

export const handler = async (event) => {
  try {
    const body =
      typeof event.body === "string"
        ? JSON.parse(event.body)
        : event.body;

    const { bookmarkId, title, url } = body;

    if (!bookmarkId || !url) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          message: "bookmarkId and url are required"
        })
      };
    }

    const item = {
      bookmarkId: {
        S: bookmarkId
      },
      title: {
        S: title || "Untitled"
      },
      url: {
        S: url
      },
      status: {
        S: "ACTIVE"
      },
      lastChecked: {
        NULL: true
      },
      lastHash: {
        NULL: true
      },
      createdAt: {
        S: new Date().toISOString()
      }
    };

    await client.send(
      new PutItemCommand({
        TableName: "BookmarkChangeTracker",
        Item: item
      })
    );

    return {
      statusCode: 201,
      body: JSON.stringify({
        message: "Bookmark registered successfully",
        bookmarkId
      })
    };

  } catch (error) {
    console.error("Error:", error);

    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Internal server error"
      })
    };
  }
};